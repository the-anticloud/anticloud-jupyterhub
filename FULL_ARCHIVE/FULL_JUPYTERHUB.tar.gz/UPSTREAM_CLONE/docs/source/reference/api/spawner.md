# Spawners

## Module: {mod}`jupyterhub.spawner`

```{eval-rst}
.. automodule:: jupyterhub.spawner
```

### {class}`SpawnException`

```{eval-rst}
.. autoclass:: SpawnException
```

### {class}`Spawner`

```{eval-rst}
.. autoconfigurable:: Spawner
   :members: options_from_form, user_options, poll, start, stop, get_args, get_env, get_state, template_namespace, format_string, create_certs, move_certs
```

### {class}`LocalProcessSpawner`

```{eval-rst}
.. autoconfigurable:: LocalProcessSpawner
```
